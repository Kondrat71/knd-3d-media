# KND 3D — публичные фотографии

Фотографии собственных изделий KND 3D для Threads @71kondrat и Instagram @71kondrat.

- `photos/buran/original-1.png` — оригинал 1 (без изменений).
- `photos/buran/original-2.png` — оригинал 2 (без изменений).
- `photos/buran/original-3.png` — оригинал 3 (без изменений).
- `photos/buran/instagram-buran.jpg` — JPEG-конверсия оригинала 2 для Instagram; геометрия и состав сцены сохранены.

Файлы предназначены для публичного размещения. В публикациях не выдавайте сгенерированные изображения за фотографии изделий.

После публикации в публичном репозитории `Kondrat71/knd-3d-media` на ветке `main` прямые ссылки будут:

Threads: https://raw.githubusercontent.com/Kondrat71/knd-3d-media/main/photos/buran/original-1.png
Instagram: https://raw.githubusercontent.com/Kondrat71/knd-3d-media/main/photos/buran/instagram-buran.jpg

Указанные ссылки начнут работать только после загрузки файлов в репозиторий.
